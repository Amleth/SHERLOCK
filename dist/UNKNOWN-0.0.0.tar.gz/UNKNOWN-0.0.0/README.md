# SHERLOCK

Documents de travail du projet SHERLOCK.

SHERLOCK : *Social sciences &amp; Humanities corpora Exploration and active Reading with Linked, Open &amp; Contributive Knowledge organisation systems*